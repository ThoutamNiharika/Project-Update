package com.capg.paymentwallet.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.service.AccountServiceImpl;
import com.capg.paymentwallet.service.IAccountService;

public class AccountServiceImplTest {
	
	static IAccountService service = null;
	static AccountBean accBean = null;
	static CustomerBean custBean = null;
	@BeforeClass
	public static void createInstance(){
		service= new AccountServiceImpl();
		accBean = new AccountBean();
		custBean = new CustomerBean();
	}
	
	@Test(expected = CustomerException.class)
	public void testForValidFirstName() throws Exception{
		custBean.setFirstName("nnn");
		custBean.setLastName("Thoutam");
		custBean.setPhoneNo("9989898955");
		custBean.setEmailId("niha@gmail.com");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress("Hyderabad");
		accBean.setBalance(10000);
		custBean.setAccountBean(accBean);
		boolean result = service.createAccount(custBean);
		assertFalse(result);
	}
	@Test(expected = CustomerException.class)
	public void testForValidLastName() throws Exception{
		custBean.setFirstName("niha");
		custBean.setLastName("th");
		custBean.setPhoneNo("9989946655");
		custBean.setEmailId("niha@gmail.com");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress("Hyderabad");
		custBean.setAccountBean(accBean);
		boolean result = service.createAccount(custBean);
		assertFalse(result);
	}
	@Test(expected = CustomerException.class)
	public void testForValidPhoneNumber() throws Exception{
		custBean.setFirstName("niha");
		custBean.setLastName("thoutam");
		custBean.setPhoneNo("122789");
		custBean.setEmailId("niha@gmail.com");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress("Hyderabad");
		custBean.setAccountBean(accBean);
		boolean result = service.createAccount(custBean);
		assertFalse(result);
	}
	@Test(expected = CustomerException.class)
	public void testForValidEmail() throws Exception{
		custBean.setFirstName("niha");
		custBean.setLastName("thoutam");
		custBean.setPhoneNo("9984567855");
		custBean.setEmailId("niha");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress("Hyderabad");
		custBean.setAccountBean(accBean);
		boolean result = service.createAccount(custBean);
		assertFalse(result);
	}
	@Test(expected = CustomerException.class)
	public void testForValidAddress() throws Exception{
		custBean.setFirstName("niha");
		custBean.setLastName("thoutam");
		custBean.setPhoneNo("12233367");
		custBean.setEmailId("niha@gmail.com");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress(null);
		custBean.setAccountBean(accBean);
		boolean result = service.createAccount(custBean);
		assertFalse(result);
	}
	@Test(expected = CustomerException.class)
	public void testForValidBalance() throws Exception{
		custBean.setFirstName("niha");
		custBean.setLastName("thoutam");
		custBean.setPhoneNo("125633");
		custBean.setEmailId("niha@gmail.com");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress("Hyderabad");
		custBean.setAccountBean(accBean);
		boolean result = service.createAccount(custBean);
		assertFalse(result);
	}
	
	@Test
	public void testDeposit() throws Exception{
		custBean.setFirstName("niha");
		custBean.setLastName("Thoutam");
		custBean.setPhoneNo("9988454555");
		custBean.setEmailId("niha@gmail.com");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress("Hyderabad");
		accBean.setBalance(10000);
		custBean.setAccountBean(accBean);
		service.deposit(custBean, 2000);
		assertEquals(12000,custBean.getAccountBean().getBalance(),0);
	
}

	@Test
	public void testWithdraw() throws Exception {
		custBean.setFirstName("niha");
		custBean.setLastName("thoutam");
		custBean.setPhoneNo("9988756785");
		custBean.setEmailId("niha@gmail.com");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress("Hyderabad");
		accBean.setBalance(10000);
		custBean.setAccountBean(accBean);
		service.withdraw(custBean, 2000);
		assertEquals(8000,custBean.getAccountBean().getBalance(),0);
	}
	
	
	@Test
	public void testFundTransfer() throws Exception {
		custBean.setFirstName("niha");
		custBean.setLastName("thoutam");
		custBean.setPhoneNo("9988334555");
		custBean.setEmailId("niha@gmail.com");
		custBean.setPanNum("TYUIOP0654");
		custBean.setAddress("Hyderabad");
		accBean.setBalance(10000);
		custBean.setAccountBean(accBean);
		CustomerBean custBean1 = new CustomerBean();
		AccountBean accBean1 = new AccountBean();
		custBean1.setFirstName("niha");
		custBean1.setLastName("thoutam");
		custBean1.setPhoneNo("9988774488");
		custBean1.setEmailId("niha@gmail.com");
		custBean1.setPanNum("TYUIOP0654");
		custBean1.setAddress("Chennai");
		accBean1.setBalance(10000);
		custBean1.setAccountBean(accBean1);
		service.fundTransfer(custBean, custBean1, 5000);
		assertEquals(15000,custBean.getAccountBean().getBalance(),0);
	}

	

}
